package com.boot.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.ms.entity.Teacher;
import com.boot.ms.service.TeacherService;

@RestController
@RequestMapping("/teachers")
public class TeacherController {
	
	@Autowired
	TeacherService service;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Teacher>> getAllTeachers() {
		return new ResponseEntity<List<Teacher>>(service.getAllTeachers(), HttpStatus.OK);
	}
	
	@GetMapping("/getTeacher/{id}")
	public ResponseEntity<?>getTeacher(@PathVariable int id) {
		Teacher teacher = service.getTeacher(id);
		ResponseEntity<?> responseEntity = null;
		
		if(teacher == null) {
			responseEntity = new ResponseEntity<String>("No teacher present with given id" +id, HttpStatus.NOT_FOUND);
		}
		else {
			responseEntity = new ResponseEntity<Teacher>(teacher, HttpStatus.OK);
		}
		return responseEntity;
	}
	
	@GetMapping("/getTeachers/{DepartmentId}")
	public ResponseEntity<?> getTeachers(@PathVariable int departmentId) {
		List<Teacher> list = service.getTeachers(departmentId);
		ResponseEntity<?> responseEntity = null;
		if(list.isEmpty()) {
			responseEntity = new ResponseEntity<String>("No teacher present with given blood group id"+departmentId, HttpStatus.OK);
		}
		else {
			responseEntity = new ResponseEntity<List<Teacher>>(list, HttpStatus.OK);
		}
		return responseEntity;
	}
	
	@PostMapping("/addTeacher")
	public ResponseEntity<Teacher> addTeacher(@RequestBody Teacher teacher) {
		Teacher teacherData = service.addTeacher(teacher);
		return new ResponseEntity<Teacher>(teacherData, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteTeacher/{id}")
	public List<Teacher> deleteTeacher(@PathVariable int id) {
		List<Teacher> list = service.deleteTeacher(id);
		ResponseEntity<?> responseEntity = null;
		if(list == null) {
			responseEntity = new ResponseEntity<String>("No teacher present with the given id" +id, HttpStatus.OK);
		}
		return list;
	}
	
	@PutMapping("/updateTeacher")
	public Teacher updateTeacher(@RequestBody Teacher teacher) {
		return service.updateTeacher(teacher);
	}
}
