package com.boot.ms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Teacher;
import com.boot.ms.repository.TeacherRepository;

@Service
public class TeacherService {
	
	@Autowired
	TeacherRepository repository;

	public List<Teacher> getAllTeachers() {
		return repository.findAll();
	}
	
	public Teacher getTeacher(int id) {
		return repository.findById(id).orElse(null);
	}
	
	public List<Teacher> getTeachers(int departmentId) {
		return repository.findAllByDepartmentId(departmentId);
	}
	
	public Teacher addTeacher(Teacher teacher) {
		return repository.save(teacher);
	}
	
	public List<Teacher> deleteTeacher(int id) {
		List<Teacher> list = null;
		Optional<Teacher> optional = repository.findById(id);
		if(optional.isPresent()) {
			repository.deleteById(id);
			list = getAllTeachers();
		}
		else {
			list = null;
		}
		return list;
	}
	
	public Teacher updateTeacher(Teacher teacher) {
		Teacher teacherData = repository.findById(teacher.getId()).get();
		teacherData.setName(teacher.getName());
		return repository.save(teacherData);
	}
}
