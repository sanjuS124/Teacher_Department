package com.boot.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherMsApplication.class, args);
	}

}
